#ifndef APPCENTERDISTRIBUTE_H
#define APPCENTERDISTRIBUTE_H
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#import <Foundation/Foundation.h>

#import "MSDistribute.h"
#import "MSDistributeDelegate.h"
#import "MSReleaseDetails.h"
#endif // APPCENTERDISTRIBUTE_H
