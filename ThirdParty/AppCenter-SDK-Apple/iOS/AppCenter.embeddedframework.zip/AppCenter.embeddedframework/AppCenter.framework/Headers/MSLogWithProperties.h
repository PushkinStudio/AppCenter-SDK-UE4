#ifndef MSLOGWITHPROPERTIES_H
#define MSLOGWITHPROPERTIES_H
#import <Foundation/Foundation.h>

#import "MSAbstractLog.h"

@interface MSLogWithProperties : MSAbstractLog

/**
 * Additional key/value pair parameters. [optional]
 */
@property(nonatomic) NSDictionary<NSString *, NSString *> *properties;

@end
#endif // MSLOGWITHPROPERTIES_H
