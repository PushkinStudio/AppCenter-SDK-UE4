#ifndef MSABSTRACTLOG_H
#define MSABSTRACTLOG_H
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#ifndef MS_ABSTRACT_LOG_H
#define MS_ABSTRACT_LOG_H

#import <Foundation/Foundation.h>

@interface MSAbstractLog : NSObject

@end

#endif
#endif // MSABSTRACTLOG_H
