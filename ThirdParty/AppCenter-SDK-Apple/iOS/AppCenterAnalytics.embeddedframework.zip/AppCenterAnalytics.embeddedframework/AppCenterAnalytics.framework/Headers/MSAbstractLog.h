#ifndef MSABSTRACTLOG_H
#define MSABSTRACTLOG_H
#import <Foundation/Foundation.h>

@interface MSAbstractLog : NSObject

@end
#endif // MSABSTRACTLOG_H
